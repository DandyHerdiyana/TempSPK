<?php
session_start();
include "db.php";
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
$result = $conn->query("SELECT id, name, email, created_at FROM users");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css"><title>Dashboard</title></head>
<body><div class="container">
<h2>User Dashboard</h2>
<p><a href="logout.php">Logout</a></p>
<table>
<tr><th>ID</th><th>Name</th><th>Email</th><th>Registered At</th></tr>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row["id"] ?></td>
<td><?= $row["name"] ?></td>
<td><?= $row["email"] ?></td>
<td><?= $row["created_at"] ?></td>
</tr>
<?php endwhile; ?>
</table>
</div></body></html>